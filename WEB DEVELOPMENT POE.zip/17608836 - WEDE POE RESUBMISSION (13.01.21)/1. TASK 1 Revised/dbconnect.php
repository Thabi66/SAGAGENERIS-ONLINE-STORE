<?php

$db_host="localhost";
$db_username="root";
$db_password="";
$db_name="SagagenerisStore";


$connection = mysqli_connect($db_host, $db_username, $db_password);
// Check connection
if (mysqli_connect_error())
{
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
}


$selectDB = mysqli_select_db($connection,$db_name);
//echo "<h1>Connected!</h1>";

if ($selectDB === FALSE) {

$sql = "CREATE DATABASE SagagenerisStore";
mysqli_query($connection, $sql);  
echo "Database ".$db_name." succesfully created";

} else {

//echo "Database already exsist"."<br>";

}

$selectDB = mysqli_select_db($connection,$db_name);


//mysqli_close($connection);

?>



