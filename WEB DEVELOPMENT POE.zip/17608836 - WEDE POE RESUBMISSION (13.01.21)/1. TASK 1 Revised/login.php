<?php
session_start();
unset($_SESSION['email']);  
include('dbconnect.php');
include_once('tblcreate.php');
$output = NULL;
$email = $pass = "";
if(isset($_POST['submit']))
{
$_SESSION['email'] = $_POST['email'];
$email = stripslashes($_POST['email']);
$pass = stripslashes($_POST['pass']);
$pass = md5($pass);
$query = "SELECT email, password FROM users WHERE email = '$email' AND password = '$pass'";
$result = mysqli_query($connection,$query);
$row = mysqli_fetch_array($result);
$x = $row['email'];
$y = $row['password'];
if(empty($email && $pass)){
$output = "Please eneter details";
}
else { 
if($x == $email && $y == $pass) 
{
 header("location:index.php");}
else {
$output = "Incorrect Username\Password";}
}

/*
if(empty($email)){
$output = "Please eneter email";
}elseif (mysqli_num_rows($result) != 1)
{
$output = "Incorrect Username / Password";
}else {
header("location:welcome.php");}
*/
}
?>

<!DOCTYPE html>
<html>

	<head>
		<title>SAGAGENERIS</title>
		<link rel="stylesheet" type="text/css" href="css\style.css"/>
		
			<style> 
	input[type=submit]{
	background-color: green;
	border: none;
	color: white;
	font-size: 20px;
	text-decoration: none;
	width:15px;
	margin: 4px 2px;
	cursor: pointer;
	text-align: center;
	border-radius: 8px;
	padding: 12px 20px;
	}
	p{
		font-size: 20px;
		font-family: Arial;
	}
	label{
		font-family: arial;
	}

</style>
	</head>
	<body>

	<!--Website Logo-->
	<div class="Logo">
		<img src="Saga Project.png">
	</div>

	<!--Form for the insertion of login details to login user-->
	<form method="post">
		<div class="input-group" style="text-align:center">
		<label style="text-align:center" >Email</label>
		<input type="email" name = "email"  value = "<?php echo $email; ?>" style="width:700px">
		</div>
		<div class="input-group">
		<label style="text-align:center">Password</label>
		<input type="password" name = "pass" style="width:700px" >
		</div>
		<div class="input-group">
		<input type="submit" name="submit" value="Login" style="width:80px" style="padding-top:10px" style="margin-top:10px">
		</div>
		
	</form>
	<p></p>
	<?php
	echo $output;
	?>
	
	<p style="text-align:center">No Account? : Click here to <a href="registration.php">Register</a></p> 
	</body>
	
</html>