<?php

session_start();
if(!isset($_SESSION['email'])){
    header("location:index.php");
}

if(isset($_POST['submit']))
{
    header("location:login.php");
    
    unset($_SESSION['email']);  
    session_destroy(); 
}

?>
<!DOCTYPE html>
<html>

<head>
	<title>SAGAGENERIS</title>
	<link rel="stylesheet" type="text/css" href="css\style.css"/>  
	<style> 
	input[type=submit]{
	background-color: green;
	border: none;
	color: white;
	font-size: 20px;
	padding: 15px 35px;
	text-decoration: none;
	margin: 4px 2px;
	cursor: pointer;
	text-align: center;
	border-radius: 8px;
	}
	p{
		font-size: 25px;
		font-family: Arial;
	}
	table{
	width:80%;
	}
	td{
		font-family: Arial;
		font-size: 25px;
	}
	button{
		width: 20px;
	}

</style>	
</head>

<body>
<!--Website Logo-->
	<div class="Logo">
		<img src="Saga Project.png">
	</div>
<center>
    <p>Logged in as user: <b><?php echo $_SESSION['email']; ?></b> </p>

        <form method="post">
            <input type="submit" name="submit" value="Logout" />
        </form>
    <br>
    <hr>
    <br>
<table border="0" cellspacing="20" cellpadding="1">
            <tr>
            <td>Item Name:</td>
            <td>Item Image:</td>
            <td>Item Price:</td>
        </tr>
<?php
// Include the database configuration file
include('dbconnect.php');

// Get images from the database
$sql = "SELECT * FROM tbl_item";
$query = mysqli_query($connection,$sql);

if(mysqli_num_rows($query) > 0){
    while($row = mysqli_fetch_assoc($query)){
        $imageURL = $row["image"];
        $imageDesc = $row["Description"];
        $sellprice = $row["sellprice"];
?>
    <tr>
    <td>
    <p><?php echo $imageDesc; ?></p>
    </td>
    <td>
    <img src="<?php echo $imageURL; ?>" alt="" />
    </td> 
    <td>
    <p><?php echo "R. ".$sellprice; ?></p>
    </td>
	<td>
	<button type="button" >Purchase</button>
	</td>
    </tr>
<?php }
}else{ ?>
    <p>No image(s) found...</p>
<?php } ?>
</table>

</center>


</body>
</html>