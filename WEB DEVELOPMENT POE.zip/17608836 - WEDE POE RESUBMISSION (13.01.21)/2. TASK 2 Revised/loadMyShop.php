<?php

// Define my connection variables

$db_host="localhost";
$db_username="root";
$db_password="";
$db_name="18008600_Task2DB";

// Line establishes a connection to MySQL

$connection = mysqli_connect($db_host, $db_username, $db_password);

// Check connection 

if (mysqli_connect_error())
{
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
ELSE{
 echo "Connection established"."<br>";
}
// Connects to a database to see if the Database exsist;

$selectDB = mysqli_select_db($connection,$db_name);

if ($selectDB === FALSE) 
{
	$sql = "CREATE DATABASE $db_name";
	mysqli_query($connection, $sql);  
	echo "Database ".$db_name." succesfully created"."<br>";
} 
else 
{
echo "Database already exsist"."<br>";
}

// select  the database

$selectDB = mysqli_select_db($connection,$db_name);

//	Checking to see if my Customer table exsist and creating if it doesn't

$sql = "CREATE TABLE `tbl_customer` (
  `CustomerID` int(10) NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) NOT NULL,
  `Points` varchar(10) NOT NULL,
  PRIMARY KEY (`CustomerID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;";

if (!mysqli_query($connection, $sql)) {
    echo "Table tbl_customer already exsists"."<br>";
} else {
    echo "Table tbl_customer has been created"."<br>";
}

//	Checking to see if my Item table exsist and creating if it doesn't

$sql2 = "CREATE TABLE`tbl_item` (
  `ItemID` int(10) NOT NULL AUTO_INCREMENT,
  `description` varchar(100) NOT NULL,
  `Quantity` int(10) NOT NULL,
  `Price` int(10) NOT NULL,
  PRIMARY KEY (`ItemID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;";

if (!mysqli_query($connection, $sql2)) {
    echo "Table tbl_item already exsists"."<br>";
} else {
    echo "Table tbl_item has been created"."<br>";
}


//	Checking to see if my Item table exsist and creating if it doesn't

$sql3 = "CREATE TABLE`tbl_order` (
  `OrderID` int(10) NOT NULL AUTO_INCREMENT,
  `OrderNumber` int(10) NOT NULL,
  `OrderTime` int(5) NOT NULL,
  `CustomerID` int(10) NOT NULL,
  `ItemID` int(10) NOT NULL,
  PRIMARY KEY (`OrderID`,`CustomerID`,`ItemID`),
  FOREIGN KEY (`CustomerID`) REFERENCES `tbl_customer` (`CustomerID`),
  FOREIGN KEY (`ItemID`) REFERENCES `tbl_item` (`ItemID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;";

if (!mysqli_query($connection, $sql3)) {
    echo "Table tbl_order already exsists"."<br>";
} else {
    echo "Table tbl_order has been created"."<br>";
}


$sqlCust = "SELECT * FROM tbl_customer";
$result = mysqli_query($connection,$sqlCust);

if ((mysqli_num_rows($result)) > 0)
{
    
}
else
	{
		//Loading the text file data to the database
			
		    $load= mysqli_query($connection,"LOAD DATA LOCAL INFILE 'Customers.txt' INTO TABLE tbl_customer FIELDS TERMINATED BY ',' (Name, Points)");

	
				if($load !== FALSE)
				{
					echo "The data has been successfully loaded"."<br>";
				}
				else
				{
				echo "The data has not been loaded."."<br>";
				}
    }
	
	
	
$sqlItem = "SELECT * FROM tbl_item";
$result = mysqli_query($connection,$sqlItem);

if ((mysqli_num_rows($result)) > 0)
{
    
}
else
	{
		//Loading the text file data to the database
			
		    $load= mysqli_query($connection,"LOAD DATA LOCAL INFILE 'Items.txt' INTO TABLE tbl_item FIELDS TERMINATED BY ',' (description, Quantity, Price)");

	
				if($load !== FALSE)
				{
					echo "The data has been successfully loaded"."<br>";
				}
				else
				{
				echo "The data has not been loaded."."<br>";
				}
    }	

    
	
$sqlOrder = "SELECT * FROM tbl_order";
$result = mysqli_query($connection,$sqlOrder);

if ((mysqli_num_rows($result)) > 0)
{
    
}
else
	{
		//Loading the text file data to the database
			
		    $load= mysqli_query($connection,"LOAD DATA LOCAL INFILE 'Orders.txt' INTO TABLE tbl_order FIELDS TERMINATED BY ',' (OrderNumber, OrderTime)");

	
				if($load !== FALSE)
				{
					echo "The data has been successfully loaded"."<br>";
				}
				else
				{
				echo "The data has not been loaded."."<br>";
				}
    }	


//mysqli_close($connection);

?>